/* source: xio-system.h */
/* Copyright Gerhard Rieger 2001-2009 */
/* Published under the GNU General Public License V.2, see file COPYING */

#ifndef __xio_system_h_included
#define __xio_system_h_included 1

extern const union xioaddr_desc *xioaddrs_system[];
extern const union xioaddr_desc *xioaddrs_system1[];

#endif /* !defined(__xio_system_h_included) */
